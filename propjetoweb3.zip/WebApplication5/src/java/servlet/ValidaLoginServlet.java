package servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/ValidaLoginServlet")
public class ValidaLoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String senha = request.getParameter("senha");
        
        if ("abc@gmail.com".equals(email) && "123".equals(senha)) {
            // Lógica de validação bem-sucedida
            // Faça as ações necessárias para lidar com o login válido
            
            // Por exemplo, redirecionar para a página inicial
            response.sendRedirect("home.jsp");
        } else {
            // Lógica de validação falhou
            // Faça as ações necessárias para lidar com o login inválido
            
            // Por exemplo, redirecionar de volta para o formulário de login com uma mensagem de erro
            request.setAttribute("mensagemErro", "Email ou senha inválidos");
            request.getRequestDispatcher("index.html").forward(request, response);
        }
    }
}
